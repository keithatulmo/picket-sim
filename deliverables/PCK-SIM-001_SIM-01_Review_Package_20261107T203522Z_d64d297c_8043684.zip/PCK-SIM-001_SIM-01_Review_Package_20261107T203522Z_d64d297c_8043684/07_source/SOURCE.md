# Source snapshot

* Archive: `picket-sim_8043684.tar.gz` = `git archive 80436845f1f120e7112eb43c897c20618a0f8067` (the commit recorded in the run of record).
* Repository HEAD when packaged: `2a81bc1087341ae03109eb67b282592005af3278`; commits after the code commit add results, the report, the errata and this packaging tool only.
* Reproduce: unpack, `python -m venv .venv && . .venv/bin/activate && pip install -r requirements.lock && pip install -e . --no-deps && make sim01`.
