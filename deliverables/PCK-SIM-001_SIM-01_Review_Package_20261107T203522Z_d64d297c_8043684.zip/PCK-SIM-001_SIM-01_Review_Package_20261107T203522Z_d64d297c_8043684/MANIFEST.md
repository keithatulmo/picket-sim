# PCK-SIM-001_SIM-01_Review_Package_20261107T203522Z_d64d297c_8043684

* Run of record: `20261107T203522Z_d64d297c_8043684`
* Code commit: `80436845f1f120e7112eb43c897c20618a0f8067`
* Packaged from repository HEAD `2a81bc1087341ae03109eb67b282592005af3278`
* Transmittal: 7 pages; engineering report: 13 pages

| File | Bytes |
|---|---|
| `00_TRANSMITTAL.md` | 16,217 |
| `00_TRANSMITTAL.pdf` | 216,065 |
| `01_SIM-01_Engineering_Report.md` | 37,258 |
| `01_SIM-01_Engineering_Report.pdf` | 3,021,122 |
| `02_figures/fig01_geometries.png` | 153,850 |
| `02_figures/fig02_horizontal_beampatterns.png` | 414,443 |
| `02_figures/fig03_vertical_beampatterns.png` | 285,056 |
| `02_figures/fig04_frequency_azimuth_maps.png` | 352,167 |
| `02_figures/fig05_sphere_ambiguity_maps.png` | 818,416 |
| `02_figures/fig06_metrics_vs_frequency.png` | 329,656 |
| `02_figures/fig07_regime_map.png` | 143,801 |
| `02_figures/fig08_line_array_sensitivity.png` | 265,485 |
| `02_figures/fig09_aperture_scaling.png` | 200,479 |
| `02_figures/fig10_sound_speed_robustness.png` | 137,241 |
| `03_tables/comparison.csv` | 1,544 |
| `03_tables/comparison.md` | 1,738 |
| `03_tables/geometry_summary.csv` | 2,017 |
| `03_tables/geometry_summary.md` | 1,224 |
| `03_tables/pareto.csv` | 870 |
| `03_tables/pareto.md` | 1,753 |
| `03_tables/pareto_leave_one_out.csv` | 2,282 |
| `03_tables/pareto_leave_one_out.md` | 2,884 |
| `03_tables/representative_frequencies.csv` | 18,270 |
| `03_tables/representative_frequencies.md` | 5,102 |
| `03_tables/robustness_sound_speed.csv` | 3,125 |
| `03_tables/robustness_sound_speed.md` | 846 |
| `03_tables/robustness_sound_speed_mismatch.csv` | 5,896 |
| `03_tables/robustness_sound_speed_mismatch.md` | 4,067 |
| `03_tables/sensitivity_a4_scale.csv` | 1,196 |
| `03_tables/sensitivity_a4_scale.md` | 609 |
| `03_tables/sensitivity_orientation.csv` | 5,334 |
| `03_tables/sensitivity_orientation.md` | 1,249 |
| `03_tables/sensitivity_square_side.csv` | 822 |
| `03_tables/sensitivity_square_side.md` | 498 |
| `03_tables/sensitivity_ula_geometry.csv` | 1,581 |
| `03_tables/sensitivity_ula_sweep.csv.gz` | 102,290 |
| `03_tables/sensitivity_ula_thresholds.csv` | 5,063 |
| `03_tables/sensitivity_ula_thresholds.md` | 3,889 |
| `03_tables/summary_by_frequency.csv` | 232,989 |
| `03_tables/sweep_metrics.csv.gz` | 591,658 |
| `03_tables/thresholds_by_steering.csv` | 22,365 |
| `03_tables/thresholds_summary.csv` | 1,938 |
| `03_tables/thresholds_summary.md` | 1,425 |
| `04_run_record/ERRATA.md` | 1,453 |
| `04_run_record/RUN_INDEX.csv` | 565 |
| `04_run_record/record.json` | 20,516 |
| `04_run_record/sim01_baseline.yaml` | 7,779 |
| `04_run_record/summary.md` | 8,205 |
| `05_verification/pytest_junit.xml` | 14,936 |
| `05_verification/pytest_log.txt` | 12,308 |
| `05_verification/self_checks.json` | 484 |
| `05_verification/test_inventory.txt` | 9,484 |
| `06_documentation/README.md` | 2,657 |
| `06_documentation/SIM-01_plan.md` | 9,754 |
| `06_documentation/adr/0001-isolated-simulation-repository.md` | 921 |
| `06_documentation/adr/0002-python-numpy-reference-implementation.md` | 1,102 |
| `06_documentation/adr/0003-coordinate-and-sign-conventions.md` | 1,171 |
| `06_documentation/adr/0004-narrowband-far-field-das-model.md` | 1,183 |
| `06_documentation/adr/0005-metric-definitions-and-undefined-metrics.md` | 1,536 |
| `06_documentation/adr/0006-immutable-run-records.md` | 879 |
| `06_documentation/adr/0007-extension-points.md` | 1,081 |
| `06_documentation/adr/README.md` | 1,070 |
| `06_documentation/assumptions.md` | 3,205 |
| `06_documentation/conventions.md` | 2,385 |
| `06_documentation/metrics.md` | 4,500 |
| `07_source/SOURCE.md` | 481 |
| `07_source/picket-sim_8043684.tar.gz` | 3,769,386 |
| `07_source/requirements.lock` | 262 |
