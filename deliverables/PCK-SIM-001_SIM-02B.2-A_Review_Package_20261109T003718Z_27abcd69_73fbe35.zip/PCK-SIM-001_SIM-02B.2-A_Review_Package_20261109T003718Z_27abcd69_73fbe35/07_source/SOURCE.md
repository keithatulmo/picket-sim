# Source snapshots and baselines

| Baseline | Commit | Archive | Use |
|---|---|---|---|
| Code commit of the run of record | `73fbe35f3999b19a6ff17f4020aa6e46ed6d5b60` | `picket-sim_73fbe35.tar.gz` | The exact code that produced the run of record (recorded in `04_run_record/record.json`). Verification log: `05_verification/pytest_log.txt`. |
| Final source baseline (packaging HEAD) | `ea7431dcb104b14d0fccd1528ad0c03f28b58e9c` | `picket-sim_ea7431d_baseline.tar.gz` | Everything committed when this package was built, including report-generation and checking tools added after the code commit, plus the run-of-record tables listed below so that documented commands run from the snapshot. Verification log: `05_verification/pytest_log_baseline.txt`; snapshot command log: `05_verification/snapshot_checks.txt`. |

Run-of-record directories embedded in the baseline archive (record.json, summary.md, tables/, and the study's ERRATA.md and RUN_INDEX.csv; figures are in `02_figures`):

* `results/sim01/20261107T203522Z_d64d297c_8043684`
* `results/sim02a/20261107T214846Z_c56c0048_31da01b`
* `results/sim02b1/20261108T125126Z_1c70e065_8dbe019`
* `results/sim02b2a/20261109T003718Z_27abcd69_73fbe35`

## Changes between the code commit and the final baseline

Library code under `src/` changed: yes, see the file list below.

* `src/picket_sim/experiments/sim02b2a.py`
* `src/picket_sim/plotting_sim02b2a.py`

Commits:

```
ea7431d 2026-11-09 Fix SIM-02B.1 claims checker test-count check (recorded inventory); record in transmittal and baselines
899f4b1 2026-11-09 SIM-02B.2-A reviewer message (final), claims check 118 of 118, source baselines
e02154a 2026-11-09 SIM-02B.2-A transmittal, reviewer message draft, claims checker (118 checks), checker tests
0570958 2026-11-09 SIM-02B.2-A run of record 20261109T003718Z_27abcd69_73fbe35, errata, derived tables, report draft
0b30e50 2026-11-09 Summary tables: count method agreement once per distinct ORACLE statistic
7b839ea 2026-11-09 Tests for the SIM-02B.2-A supplementary tools
8ab9302 2026-11-09 SIM-02B.2-A report tooling: summary tables, partial reproduction check, Makefile targets
9347f63 2026-11-09 D02 coherence collection plan, D05 loaned-sensor proposal outline, SIM-02B.2-A docs and tools
```

Changed code, configuration, test and tool files (`git diff --stat`):

```
Makefile                                          |  20 +-
 src/picket_sim/experiments/sim02b2a.py            |  31 +-
 src/picket_sim/plotting_sim02b2a.py               |   3 +-
 tests/fixtures/sim02b1_test_inventory_a394c5e.txt | 216 +++++++++
 tests/test_sim02b2a_pipeline.py                   |  18 +
 tests/test_sim02b2a_tools.py                      | 132 ++++++
 tools/check_sim02b1_claims.py                     |  19 +-
 tools/check_sim02b2a_claims.py                    | 521 ++++++++++++++++++++++
 tools/d02_collection_design.py                    | 147 ++++++
 tools/sim02b2a_b1_regression.py                   | 128 ++++++
 tools/sim02b2a_repro_check.py                     | 104 +++++
 tools/sim02b2a_summary.py                         | 308 +++++++++++++
 tools/sim02b2a_supplement.py                      | 171 +++++++
 13 files changed, 1804 insertions(+), 14 deletions(-)
```

## Reproduce

```
tar xzf picket-sim_ea7431d_baseline.tar.gz && cd picket-sim-ea7431d
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.lock && pip install -e . --no-deps
make test
```

Rendering PDFs with `tools/build_review_package.py` additionally needs `requirements-tools.lock` and Node with Playwright/Chromium.
