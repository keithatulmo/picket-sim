# Source snapshot

* Archive: `picket-sim_31da01b.tar.gz` = `git archive 31da01b5ecc8b13caf0d3a57f102b73f5c5525f4` (the commit recorded in the run of record).
* Repository HEAD when packaged: `b1b59bc454c896aa1ae608b1704b002dc95b2953`; commits after the code commit add results, the report, the errata and this packaging tool only.
* Reproduce: unpack, `python -m venv .venv && . .venv/bin/activate && pip install -r requirements.lock && pip install -e . --no-deps && make sim01`.
