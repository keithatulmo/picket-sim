# Source snapshots and baselines

| Baseline | Commit | Archive | Use |
|---|---|---|---|
| Code commit of the run of record | `8dbe0190a33dc1f3f55137e64e66d6c33f7c0cd1` | `picket-sim_8dbe019.tar.gz` | The exact code that produced the run of record (recorded in `04_run_record/record.json`). Verification log: `05_verification/pytest_log.txt`. |
| Final source baseline (packaging HEAD) | `a394c5e3044069a153902d32fe31c46deb437476` | `picket-sim_a394c5e_baseline.tar.gz` | Everything committed when this package was built, including report-generation and checking tools added after the code commit, plus the run-of-record tables listed below so that documented commands run from the snapshot. Verification log: `05_verification/pytest_log_baseline.txt`; snapshot command log: `05_verification/snapshot_checks.txt`. |

Run-of-record directories embedded in the baseline archive (record.json, summary.md, tables/, and the study's ERRATA.md and RUN_INDEX.csv; figures are in `02_figures`):

* `results/sim01/20261107T203522Z_d64d297c_8043684`
* `results/sim02a/20261107T214846Z_c56c0048_31da01b`
* `results/sim02b1/20261108T125126Z_1c70e065_8dbe019`

## Changes between the code commit and the final baseline

Library code under `src/` changed: yes, see the file list below.

* `src/picket_sim/detection.py`
* `src/picket_sim/experiments/sim02b1.py`

Commits:

```
a394c5e 2026-11-08 Record SIM-02B.1 claims check output (112 of 112)
8a1698e 2026-11-08 SIM-02B.1 report, transmittal, reviewer message draft, claims checker (112 checks)
7b63a3b 2026-11-08 SIM-02B.1 run of record 20261108T125126Z_1c70e065_8dbe019; exact calibration check
c590147 2026-11-08 SIM-02B.1 claims checker infrastructure (claims added after the run of record)
4390606 2026-11-08 CLAUDE.md: packaging and research-provenance rules from the SIM-02A review; SIM-02B.1 transmittal draft
442b813 2026-11-08 SIM-02B.1 documentation: assumptions AS-20 to AS-29, detection model doc, README; summary tool
```

Changed code, configuration, test and tool files (`git diff --stat`):

```
Makefile                              |  12 +-
 src/picket_sim/detection.py           |  40 +++-
 src/picket_sim/experiments/sim02b1.py |  36 ++--
 tests/test_sim02b1_models.py          |  20 ++
 tests/test_supplementary_tools.py     |  16 ++
 tools/check_sim02a_claims.py          |   2 +-
 tools/check_sim02b1_claims.py         | 375 ++++++++++++++++++++++++++++++++++
 tools/sim02b1_calibration_check.py    |  79 +++++++
 tools/sim02b1_summary.py              | 175 ++++++++++++++++
 9 files changed, 734 insertions(+), 21 deletions(-)
```

## Reproduce

```
tar xzf picket-sim_a394c5e_baseline.tar.gz && cd picket-sim-a394c5e
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.lock && pip install -e . --no-deps
make test
```

Rendering PDFs with `tools/build_review_package.py` additionally needs `requirements-tools.lock` and Node with Playwright/Chromium.
